const HUD_STYLE_CLASSES = ['minimal-hud', 'photo-mode'];

/** Add keyboard and clickable display modes to a playable mission HUD. */
export function installHudPresentation({ hud, toolbar, onHelp } = {}) {
  if (!hud) return;
  const syncCampaignFrame = () => {
    if (window.parent !== window) {
      const mode = HUD_STYLE_CLASSES.find(name => hud.classList.contains(name)) || 'normal';
      window.parent.postMessage({ source: 'mission-control-jr-hud', mode }, location.origin);
    }
  };

  const modes = [
    { className: 'minimal-hud', label: 'HUD', title: 'Toggle minimal HUD (F2)' },
    { className: 'photo-mode', label: 'Photo', title: 'Toggle photo mode (F3)' },
  ];
  for (const mode of modes) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hud-mode-button';
    button.textContent = mode.label;
    button.title = mode.title;
    button.setAttribute('aria-label', mode.title);
    button.setAttribute('aria-pressed', 'false');
    button.addEventListener('click', () => {
      const active = !hud.classList.contains(mode.className);
      HUD_STYLE_CLASSES.forEach(name => hud.classList.toggle(name, name === mode.className && active));
      modes.forEach(({ className }) => toolbar?.querySelector(`[data-hud-mode="${className}"]`)?.setAttribute('aria-pressed', String(className === mode.className && active)));
      syncCampaignFrame();
      button.blur();
    });
    button.dataset.hudMode = mode.className;
    toolbar?.append(button);
  }
  syncCampaignFrame();

  window.addEventListener('keydown', event => {
    if (event.code === 'F2' || event.code === 'F3') {
      if (document.querySelector('#dialog:not([hidden]), #modal:not([hidden])')) return;
      event.preventDefault();
      toolbar?.querySelector(`[data-hud-mode="${event.code === 'F2' ? 'minimal-hud' : 'photo-mode'}"]`)?.click();
    } else if (event.key === '?' && !document.querySelector('#dialog:not([hidden]), #modal:not([hidden])')) {
      onHelp?.();
    }
  });
}
