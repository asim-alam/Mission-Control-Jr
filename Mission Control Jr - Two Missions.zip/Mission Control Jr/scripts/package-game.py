"""Package the runnable project and built game, excluding dependency caches/staging audio."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse

project = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=project.parent / 'Mission Control Jr - Two Missions.zip')
args = parser.parse_args()
output = args.output.resolve()
if output.is_relative_to(project):
    raise SystemExit('Choose an output outside the project so the archive cannot include itself.')
allowed_directories = {'assets', 'dist', 'scripts', 'test', 'screenshots'}
excluded = {'node_modules', '__pycache__', 'audio-kokoro', '.git'}
files = []
for file in project.rglob('*'):
    if not file.is_file():
        continue
    relative = file.relative_to(project)
    if any(part in excluded for part in relative.parts):
        continue
    if len(relative.parts) > 1 and relative.parts[0] not in allowed_directories:
        continue
    if relative.parts[0] == 'screenshots' and not file.name.startswith('mission2-'):
        continue
    if file.suffix.lower() in {'.zip', '.wav', '.pyc', '.log'} or file.name.startswith('.env') or file.name == '.npmrc':
        continue
    files.append((file, relative))
output.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for file, relative in sorted(files):
        archive.write(file, 'Mission Control Jr/' + relative.as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None, 'Archive CRC check failed'
    required = ['mission2.html', 'mission2-demo.js', 'dist/mission2.html',
                'assets/models/rover-crewed.glb', 'assets/audio-m2/return.ogg', 'package-lock.json']
    for name in required:
        assert 'Mission Control Jr/' + name in archive.namelist(), name
print(f'{output}\n{len(files)} files\n{output.stat().st_size:,} bytes\nCRC and required files: OK')
