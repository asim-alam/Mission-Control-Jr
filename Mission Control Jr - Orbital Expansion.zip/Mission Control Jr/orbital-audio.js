// No synthetic fallback voice. Quiet generated interior sound and tactile feedback only.
export class OrbitalAudio{
  constructor(){this.muted=false;this.paused=false;}
  start(){if(this.ctx){this.ctx.resume().catch(()=>{});return;}const C=window.AudioContext||window.webkitAudioContext;if(!C)return;this.ctx=new C();this.master=this.ctx.createGain();this.master.gain.value=.3;this.master.connect(this.ctx.destination);this.hum=this.ctx.createOscillator();this.hum.type='sine';this.hum.frequency.value=62;this.level=this.ctx.createGain();this.level.gain.value=0;this.hum.connect(this.level).connect(this.master);this.hum.start();}
  update(inside){if(this.ctx)this.level.gain.setTargetAtTime(inside&&!this.paused&&!this.muted?.025:0,this.ctx.currentTime,.35);}
  ping(){if(!this.ctx||this.muted||this.paused)return;const tone=this.ctx.createOscillator(),gain=this.ctx.createGain(),now=this.ctx.currentTime;tone.frequency.setValueAtTime(580,now);tone.frequency.exponentialRampToValueAtTime(820,now+.07);gain.gain.setValueAtTime(.08,now);gain.gain.exponentialRampToValueAtTime(.001,now+.18);tone.connect(gain).connect(this.master);tone.start();tone.stop(now+.2);tone.onended=()=>{tone.disconnect();gain.disconnect();};}
  dispose(){this.hum?.stop();this.ctx?.close();}
}
